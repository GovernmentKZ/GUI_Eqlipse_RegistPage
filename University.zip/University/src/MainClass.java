import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainClass {

	private JFrame frame;
	private JTextField name;
	private JLabel numberL;
	private JTextField number;
	private JLabel timeL;
	private JTextField time;
	private JButton btnDelate;
	private JButton btnUpdate;
	private JButton btnRefresh;
	private JTable table;
	private JScrollPane scrollPane;
	
	int row;
	ArrayList<Client> clients;
	DefaultTableModel dtm;
	String header[] = new String[] {"Name","Number","Time"};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainClass window = new MainClass();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void displayStudentDetails() {
		dtm.setRowCount(0);
		for(int i = 0; i < clients.size(); i++) {
			Object[] object = {clients.get(i).name, clients.get(i).number, clients.get(i).time};
			dtm.addRow(object);
		}
	}

	/**
	 * Create the application.
	 */
	public MainClass() {
		initialize();
		clients = new ArrayList<>();
		dtm = new DefaultTableModel(header,0);
		table.setModel(dtm);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 697, 414);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(48, 35, 41, 16);
		frame.getContentPane().add(lblNewLabel);
		
		name = new JTextField();
		name.setBounds(111, 30, 130, 26);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		numberL = new JLabel("Number");
		numberL.setBounds(48, 73, 66, 16);
		frame.getContentPane().add(numberL);
		
		number = new JTextField();
		number.setColumns(10);
		number.setBounds(111, 68, 130, 26);
		frame.getContentPane().add(number);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client client = new Client(name.getText(), number.getText(), time.getText());
				clients.add(client);
				displayStudentDetails();
			}
		});
		btnNewButton.setBounds(48, 167, 87, 26);
		frame.getContentPane().add(btnNewButton);
		
		timeL = new JLabel("Time");
		timeL.setBounds(48, 107, 66, 16);
		frame.getContentPane().add(timeL);
		
		time = new JTextField();
		time.setColumns(10);
		time.setBounds(111, 102, 130, 26);
		frame.getContentPane().add(time);
		
		btnDelate = new JButton("Delate");
		btnDelate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int choice = JOptionPane.showConfirmDialog(null, "Delete this data?", "Delete", JOptionPane.YES_NO_OPTION);
				if(choice == 0) {
					dtm.removeRow(row);
					clients.remove(row);
					displayStudentDetails();
				}
			}
		});
		btnDelate.setBounds(154, 166, 87, 26);
		frame.getContentPane().add(btnDelate);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clients.get(row).name = name.getText();
				clients.get(row).number = number.getText();
				clients.get(row).time = time.getText();
				displayStudentDetails();
			}
		});
		btnUpdate.setBounds(48, 205, 87, 26);
		frame.getContentPane().add(btnUpdate);
		
		btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				name.setText("");
				number.setText("");
				time.setText("");
			}
		});
		btnRefresh.setBounds(154, 204, 87, 26);
		frame.getContentPane().add(btnRefresh);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(280, 36, 384, 195);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				row=table.getSelectedRow();
				name.setText(dtm.getValueAt(row, 0).toString());
				number.setText(dtm.getValueAt(row, 1).toString());
				time.setText(dtm.getValueAt(row, 2).toString());
			}
		});
		scrollPane.setViewportView(table);
	}
}
